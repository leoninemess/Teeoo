<!DOCTYPE html>
<html lang="en">

    <head>
        <?php echo meta_init(); ?>

        <meta name="keywords" content="<?php echo Theme::get('keywords'); ?>">
        <meta name="description" content="<?php echo Theme::get('description'); ?>">
        <meta name="author" content="<?php echo Theme::get('author'); ?>">
        <meta name="renderer" content="webkit">
        <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
        <link rel="stylesheet/less" href="/themes/candy-rebirth/assets/css/w.less">
        <script src="https://cdn.bootcss.com/highlight.js/9.12.0/highlight.min.js"></script>
        <link href="https://cdn.bootcss.com/highlight.js/9.12.0/styles/vs2015.min.css" rel="stylesheet">
        <title><?php echo Theme::get('title'); ?></title>
        <?php echo Theme::asset()->styles(); ?>
        <style>
            .page-container{
                justify-content: center;
            }
            .menu .group .item{
                color:#dedede;
            }
            .menu .group .item:hover{
                color:#fafafa;
                text-shadow: 1px 1px 10px rgba(255,255,255,0.2), 1px 1px 10px rgba(255,255,255,0.2);
            }
            .menu .group .item:active{
                color:#ffffff;
            }
            .menu .group .drop-down{
                color:#dedede;
            }
        </style>
    </head>

    <body>
        <?php echo Theme::partial('header'); ?>

        <?php echo Theme::content(); ?>

        <?php echo Theme::partial('footer'); ?>

        <?php echo Theme::asset()->scripts(); ?>
    </body>

</html>
