<section id="main">
	Main Section
	<small>
		[<?php echo protectEmail('email@example.com'); ?>]
	</small>
</section>