<div class="bg" style="background-image:url('https://qwq.moe/usr/uploads/2018/04/2882846731.jpg');"></div>
<div class="notify-container"></div>