<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>404</title>
    <link href="/404/css/pintuer.css" rel="stylesheet"/>
</head>

<body>
<div class="container" style=" margin-top:8%;">
    <div class="panel margin-big-top">
        <div class="text-center">
            <br>
            <h2 class="padding-top"> <stong>404错误！抱歉您要找的页面不存在</stong> </h2>
            <div class="">
                <div class="float-left">
                    <img src="http://www.pintuer.com/images/ds-1.gif">
                    <div class="alert"> MMP！页面不见了！我好鸡冻啊. </div>
                </div>
                <div class="float-right">
                    <img src="http://www.pintuer.com/images/ds-2.png" width="260">
                </div>
            </div>
            <div class="padding-big">
                <a href="/" class="button bg-yellow">返回首页</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
